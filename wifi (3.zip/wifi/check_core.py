import sys
sys.path.insert(0, '.')
from core.transfer import FileReceiver, send_file, DEFAULT_PORT
from core.network import get_all_adapters, get_all_local_ips, format_size, format_speed, format_eta

print('core.transfer: OK')
print('core.network: OK')
print('Default port:', DEFAULT_PORT)

adapters = get_all_adapters()
print('Adapters found:', len(adapters))
for a in adapters:
    print('  [' + a['type'] + '] ' + a['ip'] + '  ' + a['name'])

ips = get_all_local_ips()
print('Local IPs:', ips)
print('format_size:', format_size(1536000))
print('format_speed:', format_speed(125.6))
print('format_eta:', format_eta(127))
