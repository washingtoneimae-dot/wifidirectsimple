"""
test_error_handling.py — Unit and integration tests for error handling and handshakes.
"""

import sys
import os
import socket
import time
import tempfile
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.transfer import FileReceiver, send_file, DEFAULT_PORT, MAGIC_HEADER

def test_nonexistent_file():
    print("Testing nonexistent file handling...")
    p = send_file("127.0.0.1", "C:\\non_existent_file_12345.bin", port=5998)
    assert p.error is not None, "Should report error for missing file"
    print(f"  [PASS] Correctly returned error: {p.error}")

def test_connection_refused():
    print("Testing connection refused (no receiver)...")
    temp_f = tempfile.NamedTemporaryFile(delete=False)
    temp_f.write(b"hello world")
    temp_f.close()
    
    p = send_file("127.0.0.1", temp_f.name, port=5997)
    assert p.error is not None, "Should report connection refused"
    print(f"  [PASS] Correctly returned error: {p.error}")
    os.unlink(temp_f.name)

def test_bad_magic_handshake():
    print("Testing rogue client / bad magic handshake rejection...")
    recv_dir = tempfile.mkdtemp()
    receiver = FileReceiver(save_dir=recv_dir, port=5996)
    receiver.start()
    time.sleep(0.2)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("127.0.0.1", 5996))
    sock.sendall(b"BAD_MAGIC_HEADER")
    resp = sock.recv(1024)
    sock.close()
    receiver.stop()

    assert len(resp) >= 3, "Receiver should send rejection handshake"
    status_code = resp[0]
    assert status_code != 0x00, "Receiver must reject invalid magic header"
    print(f"  [PASS] Receiver rejected rogue packet with status code: {status_code}")

if __name__ == "__main__":
    print("=== Running Error Handling & Handshake Test Suite ===")
    test_nonexistent_file()
    test_connection_refused()
    test_bad_magic_handshake()
    print("=== All Error Handling Tests Passed Successfully! ===")
