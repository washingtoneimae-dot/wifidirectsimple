"""
Benchmark and integrity verification test for transfer engine.
Creates a temporary 50MB file, starts receiver on 127.0.0.1, transfers it, verifies SHA-256 and measures speed.
"""

import os
import sys
import time
import hashlib
import tempfile
import threading
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.transfer import FileReceiver, send_file, TransferProgress
from core.network import format_size, format_speed

def calculate_sha256(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

def test_speed_and_integrity():
    print("=== Testing File Transfer Core: Speed & Integrity ===")
    
    # 1. Create a 50MB random test file
    test_size_mb = 50
    test_size_bytes = test_size_mb * 1024 * 1024
    
    temp_dir = tempfile.mkdtemp()
    recv_dir = tempfile.mkdtemp()
    source_file = os.path.join(temp_dir, "benchmark_payload.bin")
    
    print(f"1. Generating {test_size_mb} MB test payload...")
    with open(source_file, "wb") as f:
        chunk = os.urandom(1024 * 1024)
        for _ in range(test_size_mb):
            f.write(chunk)
            
    source_hash = calculate_sha256(source_file)
    print(f"   Source SHA-256: {source_hash[:16]}... (Full: {source_hash})")
    
    # 2. Start Receiver
    test_port = 5999
    done_event = threading.Event()
    received_progress = None
    
    def on_done(p: TransferProgress):
        nonlocal received_progress
        received_progress = p
        done_event.set()
        
    receiver = FileReceiver(save_dir=recv_dir, port=test_port)
    receiver.start(done_callback=on_done)
    time.sleep(0.3)
    
    # 3. Send file over loopback
    print(f"2. Transferring {test_size_mb} MB file over TCP (Port {test_port})...")
    t0 = time.perf_counter()
    send_progress = send_file(
        host="127.0.0.1",
        filepath=source_file,
        port=test_port
    )
    
    # Wait for receiver to finish
    done_event.wait(timeout=10)
    elapsed = time.perf_counter() - t0
    
    receiver.stop()
    
    # 4. Results & Verification
    speed_mb_s = test_size_mb / elapsed if elapsed > 0 else 0
    print(f"3. Transfer finished in {elapsed:.3f} seconds!")
    print(f"   Transfer Speed: {speed_mb_s:.2f} MB/s ({speed_mb_s * 8:.2f} Mbps)")
    
    dest_file = os.path.join(recv_dir, "benchmark_payload.bin")
    if not os.path.exists(dest_file):
        print("[ERROR] Destination file was not created!")
        return False
        
    dest_hash = calculate_sha256(dest_file)
    print(f"   Received SHA-256: {dest_hash[:16]}... (Full: {dest_hash})")
    
    if source_hash == dest_hash:
        print("[PASS] INTEGRITY CHECK PASSED: Hashes match bit-for-bit!")
    else:
        print("[FAIL] INTEGRITY CHECK FAILED: Hash mismatch!")
        return False
        
    # Cleanup
    try:
        os.remove(source_file)
        os.remove(dest_file)
        os.rmdir(temp_dir)
        os.rmdir(recv_dir)
    except Exception:
        pass
        
    return True

if __name__ == "__main__":
    success = test_speed_and_integrity()
    sys.exit(0 if success else 1)
