"""
test_transfer.py — Standalone test for the file transfer core.
Run this on BOTH machines to verify transfer works before using the full UI.

Usage:
  Receiver machine:  python test_transfer.py receive
  Sender machine:    python test_transfer.py send <receiver_ip> <file_path>

Example:
  python test_transfer.py receive
  python test_transfer.py send 192.168.137.1 C:\\Users\\you\\test.zip
"""

import sys
import os
import time
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.transfer import FileReceiver, send_file, DEFAULT_PORT
from core.network import get_all_local_ips, format_size, format_speed, format_eta, get_all_adapters


def run_receiver():
    save_dir = os.path.join(os.path.expanduser("~"), "Downloads", "WiFiTransfer_test")
    print(f"\n=== RECEIVER MODE ===")
    print(f"Save directory: {save_dir}")

    ips = get_all_local_ips()
    print(f"\nYour IP addresses:")
    for ip in ips:
        print(f"  → {ip}")

    adapters = get_all_adapters()
    print(f"\nNetwork adapters:")
    for a in adapters:
        print(f"  [{a['type']:12s}] {a['name'][:40]:40s} {a['ip']}")

    print(f"\nListening on port {DEFAULT_PORT}...")
    print("Press Ctrl+C to stop.\n")

    done_event = threading.Event()

    def on_progress(p):
        bar_len = 30
        filled = int(bar_len * p.percent / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        print(
            f"\r  [{bar}] {p.percent:5.1f}%  "
            f"{format_speed(p.speed_mbps):10s}  "
            f"ETA {format_eta(p.eta_seconds)}   ",
            end="", flush=True
        )

    def on_done(p):
        print()
        if p.error:
            print(f"  ✗ Error: {p.error}")
        else:
            print(f"  ✓ Received '{p.filename}' ({format_size(p.total_bytes)})")
            print(f"    Time: {p.elapsed:.1f}s  Speed: {format_speed(p.speed_mbps)}")
        done_event.set()

    receiver = FileReceiver(save_dir=save_dir, port=DEFAULT_PORT)
    receiver.start(
        progress_callback=on_progress,
        done_callback=on_done,
        status_callback=lambda msg: print(f"  [{msg}]"),
    )

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping receiver.")
        receiver.stop()


def run_sender(host: str, filepath: str):
    import os
    print(f"\n=== SENDER MODE ===")
    print(f"Target: {host}:{DEFAULT_PORT}")
    print(f"File:   {filepath} ({format_size(os.path.getsize(filepath))})")
    print()

    def on_progress(p):
        bar_len = 30
        filled = int(bar_len * p.percent / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        print(
            f"\r  [{bar}] {p.percent:5.1f}%  "
            f"{format_speed(p.speed_mbps):10s}  "
            f"ETA {format_eta(p.eta_seconds)}   ",
            end="", flush=True
        )

    t0 = time.monotonic()
    progress = send_file(
        host=host,
        filepath=filepath,
        progress_callback=on_progress,
    )
    print()

    if progress.error:
        print(f"  ✗ Error: {progress.error}")
        sys.exit(1)
    else:
        elapsed = time.monotonic() - t0
        size = os.path.getsize(filepath)
        speed = (size / elapsed) / (1024 * 1024) if elapsed > 0 else 0
        print(f"  ✓ Sent '{progress.filename}'")
        print(f"    Time: {elapsed:.1f}s  Speed: {format_speed(speed)}")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    mode = sys.argv[1].lower()

    if mode == "receive":
        run_receiver()
    elif mode == "send":
        if len(sys.argv) < 4:
            print("Usage: python test_transfer.py send <ip> <filepath>")
            sys.exit(1)
        run_sender(sys.argv[2], sys.argv[3])
    else:
        print(f"Unknown mode: {mode}")
        print("Use 'receive' or 'send'")
        sys.exit(1)


if __name__ == "__main__":
    main()
