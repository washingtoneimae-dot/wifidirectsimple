"""
network.py — Network adapter discovery and IP enumeration helpers.

Provides utilities to:
  - Get all local IPv4 addresses
  - Detect the WiFi Direct virtual adapter and its IP
  - Parse netsh output for adapter/IP info
  - Check WiFi Direct hardware capability
"""

import subprocess
import socket
import re
import logging
from typing import List, Optional, Dict

logger = logging.getLogger(__name__)


def get_all_adapters() -> List[Dict[str, str]]:
    """
    Parse ipconfig output and return a list of adapter dicts:
    [{"name": "...", "ip": "...", "type": "wifi_direct"|"wifi"|"ethernet"|"other"}]
    """
    adapters = []
    try:
        result = subprocess.run(
            ["ipconfig", "/all"],
            capture_output=True, text=True, timeout=8
        )
        output = result.stdout

        # Split into adapter blocks
        blocks = re.split(r'\n(?=\S)', output)
        for block in blocks:
            lines = block.strip().split('\n')
            if not lines:
                continue
            name_line = lines[0].strip().rstrip(':')

            # Find IPv4 address in this block
            ip = None
            for line in lines[1:]:
                m = re.search(r'IPv4 Address.*?:\s*([\d.]+)', line)
                if m:
                    ip_candidate = m.group(1).strip()
                    # Skip loopback and APIPA
                    if ip_candidate.startswith('127.') or ip_candidate.startswith('169.254.'):
                        continue
                    ip = ip_candidate
                    break

            if ip:
                # Classify adapter type
                name_lower = name_line.lower()
                if 'wi-fi direct' in name_lower or 'wifi direct' in name_lower or 'local area connection* ' in name_lower:
                    atype = 'wifi_direct'
                elif 'wi-fi' in name_lower or 'wireless' in name_lower or 'wlan' in name_lower:
                    atype = 'wifi'
                elif 'ethernet' in name_lower or 'local area connection' in name_lower:
                    atype = 'ethernet'
                else:
                    atype = 'other'

                adapters.append({"name": name_line, "ip": ip, "type": atype})
    except Exception as e:
        logger.warning(f"get_all_adapters error: {e}")
    return adapters


def get_wifi_direct_ip() -> Optional[str]:
    """Return the IP of the WiFi Direct virtual adapter, or None."""
    for adapter in get_all_adapters():
        if adapter["type"] == "wifi_direct":
            return adapter["ip"]
    return None


def get_best_transfer_ip() -> Optional[str]:
    """
    Return the most suitable IP for file transfer.
    Prefers WiFi Direct adapter, then WiFi, then Ethernet.
    """
    adapters = get_all_adapters()
    for atype in ("wifi_direct", "wifi", "ethernet", "other"):
        for adapter in adapters:
            if adapter["type"] == atype:
                return adapter["ip"]
    return None


def get_all_local_ips() -> List[str]:
    """Return all non-loopback, non-APIPA local IPv4 addresses."""
    return [a["ip"] for a in get_all_adapters()]


def check_wifi_direct_hardware() -> Dict[str, object]:
    """
    Check WiFi Direct hardware capability via netsh.
    Returns dict with keys:
      - supported: bool
      - group_owner: bool  (can act as GO / host)
      - client: bool       (can act as client)
      - raw: str           (raw netsh output)
    """
    result = {
        "supported": False,
        "group_owner": False,
        "client": False,
        "raw": "",
    }

    try:
        proc = subprocess.run(
            ["netsh", "wlan", "show", "wirelesscapabilities"],
            capture_output=True, text=True, timeout=8
        )
        raw = proc.stdout + proc.stderr
        result["raw"] = raw

        raw_lower = raw.lower()
        if "wi-fi direct" in raw_lower or "wifidirect" in raw_lower:
            result["supported"] = True

            # Check Group Owner support
            go_match = re.search(
                r'(group owner|go).*?:\s*(\w+)', raw, re.IGNORECASE
            )
            if go_match:
                result["group_owner"] = "supported" in go_match.group(2).lower()

            # Check Client support
            client_match = re.search(
                r'client.*?:\s*(\w+)', raw, re.IGNORECASE
            )
            if client_match:
                result["client"] = "supported" in client_match.group(1).lower()

        # Hosted network = can do Legacy AP
        if "hosted network" in raw_lower:
            result["supported"] = True

    except Exception as e:
        result["raw"] = str(e)
        logger.warning(f"Hardware check error: {e}")

    return result


def check_port_available(port: int) -> bool:
    """Return True if the given TCP port is available on all interfaces."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("0.0.0.0", port))
            return True
    except OSError:
        return False


def format_size(n_bytes: int) -> str:
    """Human-readable file size."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n_bytes < 1024 or unit == "TB":
            if unit == "B":
                return f"{n_bytes} {unit}"
            return f"{n_bytes:.1f} {unit}"
        n_bytes /= 1024
    return f"{n_bytes:.1f} TB"


def format_speed(mb_per_sec: float) -> str:
    """Human-readable transfer speed."""
    if mb_per_sec >= 1000:
        return f"{mb_per_sec/1000:.2f} GB/s"
    if mb_per_sec >= 1:
        return f"{mb_per_sec:.1f} MB/s"
    return f"{mb_per_sec*1024:.0f} KB/s"


def format_eta(seconds: float) -> str:
    """Human-readable ETA."""
    if seconds <= 0 or seconds > 86400:
        return "--"
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    if h > 0:
        return f"{h}h {m}m {s}s"
    if m > 0:
        return f"{m}m {s}s"
    return f"{s}s"
