@echo off
py -3 -c "import sys" >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python from https://www.python.org/downloads/
  pause
  exit /b 1
)
py -3 "%~dp0app.py"
