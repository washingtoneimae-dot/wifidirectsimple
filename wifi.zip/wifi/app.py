"""PeerDrop LAN - simple peer-to-peer file transfer for PCs on the same Wi-Fi.

Run on every PC with:  python app.py
No cloud account or external server is required.
"""
from __future__ import annotations

import json
import os
import queue
import re
import socket
import struct
import subprocess
import threading
import time
import uuid
from pathlib import Path
from tkinter import Tk, StringVar, BooleanVar, filedialog, messagebox
from tkinter import ttk

APP_NAME = "PeerDrop LAN"
DISCOVERY_PORT = 45871
TRANSFER_PORT = 45872
MAGIC = "PEERDROP1"
MAX_META = 64 * 1024
CHUNK_SIZE = 256 * 1024


def local_name() -> str:
    return socket.gethostname() or "This PC"


def safe_filename(name: str) -> str:
    """Keep a received filename inside the Downloads destination."""
    name = Path(name).name.strip()
    return name or "received-file"


def unique_destination(folder: Path, filename: str) -> Path:
    target = folder / safe_filename(filename)
    stem, suffix = target.stem, target.suffix
    n = 1
    while target.exists():
        target = folder / f"{stem} ({n}){suffix}"
        n += 1
    return target


def pack_header(data: dict) -> bytes:
    raw = json.dumps(data, separators=(",", ":")).encode("utf-8")
    return struct.pack("!I", len(raw)) + raw


def recv_exact(sock: socket.socket, count: int) -> bytes:
    data = bytearray()
    while len(data) < count:
        block = sock.recv(count - len(data))
        if not block:
            raise ConnectionError("Connection closed unexpectedly")
        data.extend(block)
    return bytes(data)


def recv_header(sock: socket.socket) -> dict:
    size = struct.unpack("!I", recv_exact(sock, 4))[0]
    if not 0 < size <= MAX_META:
        raise ValueError("Invalid transfer metadata")
    return json.loads(recv_exact(sock, size).decode("utf-8"))


def format_size(size: int) -> str:
    units = ("B", "KB", "MB", "GB", "TB")
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{size} B"


def parse_wifi_status(netsh_output: str) -> tuple[str, str]:
    """Return Windows netsh Wi-Fi connection state and SSID without shell parsing."""
    state = "Unavailable"
    ssid = ""
    for line in netsh_output.splitlines():
        match = re.match(r"^\s*State\s*:\s*(.+)$", line, re.IGNORECASE)
        if match:
            state = match.group(1).strip().title()
        match = re.match(r"^\s*SSID\s*:\s*(.+)$", line, re.IGNORECASE)
        if match and not line.lstrip().lower().startswith("bssid"):
            ssid = match.group(1).strip()
    return state, ssid


def preferred_address(addresses: list[str]) -> tuple[str | None, int]:
    """Prefer a normal home/office LAN address over VPN and virtual adapters."""
    usable = [address for address in addresses if not address.startswith(("127.", "169.254."))]
    private = []
    for address in usable:
        first, second, *_ = (int(part) for part in address.split("."))
        if first == 10 or (first == 172 and 16 <= second <= 31) or (first == 192 and second == 168):
            private.append(address)
    candidates = private or usable
    return (candidates[0], len(usable) - 1) if candidates else (None, 0)


def network_summary() -> str:
    """Collect a useful local-network status while still allowing wired connections."""
    try:
        result = subprocess.run(["netsh", "wlan", "show", "interfaces"], capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=4, check=False)
        wifi_state, ssid = parse_wifi_status(result.stdout)
    except (OSError, subprocess.SubprocessError):
        wifi_state, ssid = "Unavailable", ""
    addresses: list[str] = []
    try:
        result = subprocess.run(["ipconfig"], capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=4, check=False)
        addresses = re.findall(r"IPv4[^:]*:\s*([0-9]{1,3}(?:\.[0-9]{1,3}){3})", result.stdout)
    except (OSError, subprocess.SubprocessError):
        pass
    addresses = list(dict.fromkeys(addresses))
    primary, additional_count = preferred_address(addresses)
    wifi_text = f"Wi-Fi: {wifi_state}" + (f" ({ssid})" if ssid and wifi_state.lower() == "connected" else "")
    address_text = primary or "No local IPv4 address detected"
    if primary and additional_count:
        address_text += f"  (+{additional_count} other adapter address{'es' if additional_count != 1 else ''})"
    return f"{wifi_text}  |  This PC IP: {address_text}"


class NetworkService:
    """UDP discovery plus a small TCP file-transfer protocol."""

    def __init__(self, event_queue: queue.Queue, device_name: str, receive_folder: Path,
                 transfer_port: int = TRANSFER_PORT):
        self.events = event_queue
        self.device_name = device_name
        self.receive_folder = receive_folder
        self.transfer_port = transfer_port
        self.id = str(uuid.uuid4())
        self.running = threading.Event()
        self.running.set()
        self.peers: dict[str, dict] = {}
        self.pending: dict[str, dict] = {}
        self.pending_lock = threading.Lock()
        self.server_lock = threading.Lock()
        self.broadcast_enabled = True
        self.receiver_enabled = threading.Event()
        self.receiver_enabled.set()
        self.server: socket.socket | None = None

    def start(self) -> None:
        threading.Thread(target=self._announce_loop, daemon=True, name="discovery").start()
        threading.Thread(target=self._listen_discovery, daemon=True, name="discovery-listener").start()
        self._start_listener()

    def _start_listener(self) -> None:
        threading.Thread(target=self._listen_transfers, daemon=True, name="transfer-listener").start()

    def stop(self) -> None:
        self.running.clear()
        self.receiver_enabled.clear()
        with self.server_lock:
            server, self.server = self.server, None
        if server:
            try:
                server.close()
            except OSError:
                pass

    def set_receiving(self, enabled: bool) -> None:
        """Pause only new incoming transfers; active transfers are allowed to finish."""
        if enabled:
            self.receiver_enabled.set()
            with self.server_lock:
                should_start = self.server is None
            if should_start and self.running.is_set():
                self._start_listener()
            self.events.put(("receiver_state", True))
            return
        self.receiver_enabled.clear()
        with self.server_lock:
            server, self.server = self.server, None
        if server:
            try:
                server.close()
            except OSError:
                pass
        self.events.put(("receiver_state", False))

    def set_name(self, name: str) -> None:
        self.device_name = name.strip() or local_name()
        self._announce()

    def add_manual_peer(self, address: str) -> None:
        """Add a PC by IP address when a router blocks broadcast discovery."""
        host, _, supplied_port = address.strip().partition(":")
        if not host:
            self.events.put(("error", "Enter a PC IP address, for example 192.168.1.24."))
            return
        try:
            port = int(supplied_port) if supplied_port else self.transfer_port
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            self.events.put(("error", "Use a valid port number."))
            return
        peer_id = f"manual:{host}:{port}"
        self.peers[peer_id] = {"id": peer_id, "name": f"PC at {host}", "host": host,
                               "port": port, "seen": time.time()}
        self.events.put(("peer", self.peers[peer_id], True))

    def _announcement(self) -> bytes:
        return json.dumps({"magic": MAGIC, "id": self.id, "name": self.device_name,
                           "port": self.transfer_port}).encode("utf-8")

    def _announce(self) -> None:
        if not self.broadcast_enabled:
            return
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.sendto(self._announcement(), ("255.255.255.255", DISCOVERY_PORT))
        except OSError:
            pass

    def _announce_loop(self) -> None:
        while self.running.is_set():
            self._announce()
            self._remove_stale_peers()
            time.sleep(3)

    def _remove_stale_peers(self) -> None:
        now = time.time()
        gone = [key for key, peer in self.peers.items()
                if not key.startswith("manual:") and now - peer["seen"] > 10]
        for key in gone:
            self.peers.pop(key, None)
            self.events.put(("peer_removed", key))

    def _listen_discovery(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("", DISCOVERY_PORT))
            sock.settimeout(1)
            while self.running.is_set():
                try:
                    data, address = sock.recvfrom(4096)
                    packet = json.loads(data.decode("utf-8"))
                    if packet.get("magic") != MAGIC or packet.get("id") == self.id:
                        continue
                    peer_id = packet["id"]
                    new = peer_id not in self.peers
                    self.peers[peer_id] = {"id": peer_id, "name": packet.get("name", "Unknown PC"),
                                           "host": address[0], "port": int(packet.get("port", TRANSFER_PORT)),
                                           "seen": time.time()}
                    self.events.put(("peer", self.peers[peer_id], new))
                except socket.timeout:
                    continue
                except (OSError, ValueError, KeyError, json.JSONDecodeError):
                    continue
        finally:
            sock.close()

    def _listen_transfers(self) -> None:
        if not self.receiver_enabled.is_set():
            return
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # On Windows, REUSEADDR can silently share a port with another listener.
        # Exclusive ownership ensures incoming files reach this app instance.
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            server.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        else:
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind(("", self.transfer_port))
            server.listen(5)
            server.settimeout(1)
            with self.server_lock:
                if not self.receiver_enabled.is_set() or not self.running.is_set():
                    return
                self.server = server
            self.events.put(("status", f"Ready on port {self.transfer_port}"))
            self.events.put(("receiver_state", True))
            while self.running.is_set() and self.receiver_enabled.is_set():
                try:
                    conn, address = server.accept()
                    threading.Thread(target=self._receive_connection, args=(conn, address), daemon=True).start()
                except socket.timeout:
                    continue
                except OSError:
                    break
        except OSError as error:
            if self.receiver_enabled.is_set() and self.running.is_set():
                self.events.put(("error", f"Could not start receiver: {error}"))
        finally:
            try:
                server.close()
            except OSError:
                pass
            with self.server_lock:
                if self.server is server:
                    self.server = None

    def _receive_connection(self, conn: socket.socket, address: tuple) -> None:
        token = str(uuid.uuid4())
        try:
            conn.settimeout(45)
            meta = recv_header(conn)
            if meta.get("magic") != MAGIC or meta.get("type") != "file":
                raise ValueError("Not a PeerDrop transfer")
            size = int(meta["size"])
            if size < 0:
                raise ValueError("Invalid file size")
            request = {"token": token, "conn": conn, "address": address[0], "name": safe_filename(meta["name"]),
                       "size": size, "sender": str(meta.get("sender", "Unknown PC"))}
            with self.pending_lock:
                self.pending[token] = request
            self.events.put(("incoming", request))
        except Exception as error:
            try:
                conn.sendall(pack_header({"accepted": False, "reason": str(error)}))
            except OSError:
                pass
            conn.close()

    def respond_to_incoming(self, token: str, accepted: bool) -> None:
        with self.pending_lock:
            request = self.pending.pop(token, None)
        if not request:
            return
        if not accepted:
            try:
                request["conn"].sendall(pack_header({"accepted": False, "reason": "Declined"}))
            except OSError:
                pass
            request["conn"].close()
            return
        threading.Thread(target=self._save_received_file, args=(request,), daemon=True).start()

    def _save_received_file(self, request: dict) -> None:
        conn, size = request["conn"], request["size"]
        destination: Path | None = None
        try:
            self.receive_folder.mkdir(parents=True, exist_ok=True)
            destination = unique_destination(self.receive_folder, request["name"])
            conn.sendall(pack_header({"accepted": True}))
            received = 0
            with open(destination, "wb") as stream:
                while received < size:
                    block = conn.recv(min(CHUNK_SIZE, size - received))
                    if not block:
                        raise ConnectionError("Sender disconnected")
                    stream.write(block)
                    received += len(block)
                    self.events.put(("receive_progress", request["name"], received, size))
            conn.sendall(pack_header({"completed": True}))
            self.events.put(("received", destination))
        except Exception as error:
            if destination and destination.exists():
                try:
                    destination.unlink()
                except OSError:
                    pass
            try:
                conn.sendall(pack_header({"completed": False, "reason": str(error)}))
            except OSError:
                pass
            self.events.put(("error", f"Receiving {request['name']} failed: {error}"))
        finally:
            conn.close()

    def send_file(self, peer_id: str, path: Path) -> None:
        peer = self.peers.get(peer_id)
        if not peer:
            self.events.put(("error", "That device is no longer online."))
            return
        threading.Thread(target=self._send_file_worker, args=(peer, path), daemon=True).start()

    def _send_file_worker(self, peer: dict, path: Path) -> None:
        try:
            size = path.stat().st_size
            with socket.create_connection((peer["host"], peer["port"]), timeout=15) as sock:
                # A person may reasonably take time to review an incoming-file prompt.
                sock.settimeout(300)
                sock.sendall(pack_header({"magic": MAGIC, "type": "file", "name": path.name, "size": size,
                                          "sender": self.device_name}))
                reply = recv_header(sock)
                if not reply.get("accepted"):
                    raise PermissionError(reply.get("reason", "Transfer declined"))
                sent = 0
                with open(path, "rb") as stream:
                    while block := stream.read(CHUNK_SIZE):
                        sock.sendall(block)
                        sent += len(block)
                        self.events.put(("send_progress", path.name, sent, size, peer["name"]))
                sock.shutdown(socket.SHUT_WR)
                confirmation = recv_header(sock)
                if not confirmation.get("completed"):
                    raise IOError(confirmation.get("reason", "Receiver did not confirm the saved file"))
            self.events.put(("sent", path.name, peer["name"]))
        except Exception as error:
            self.events.put(("error", f"Sending {path.name} failed: {error}"))


class PeerDropApp:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("720x620")
        self.root.minsize(620, 500)
        self.events: queue.Queue = queue.Queue()
        self.device_name = StringVar(value=local_name())
        self.manual_address = StringVar()
        self.folder = Path.home() / "Downloads" / "PeerDrop"
        self.folder_text = StringVar(value=str(self.folder))
        self.status = StringVar(value="Starting…")
        self.network_text = StringVar(value="Checking network…")
        self.receiver_text = StringVar(value="Receiver is starting…")
        self.progress_text = StringVar(value="No active transfer")
        self.auto_accept = BooleanVar(value=False)
        self.service = NetworkService(self.events, self.device_name.get(), self.folder)
        self._build()
        self.refresh_network()
        self.service.start()
        self.root.after(100, self._process_events)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _build(self) -> None:
        pad = {"padx": 12, "pady": 7}
        top = ttk.Frame(self.root, padding=12)
        top.pack(fill="x")
        ttk.Label(top, text=APP_NAME, font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Label(top, textvariable=self.status).pack(side="right")

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.send_tab = ttk.Frame(self.tabs, padding=0)
        self.receive_tab = ttk.Frame(self.tabs, padding=0)
        self.tabs.add(self.send_tab, text="Send")
        self.tabs.add(self.receive_tab, text="Receive")

        settings = ttk.LabelFrame(self.send_tab, text="This PC and network", padding=10)
        settings.pack(fill="x", pady=(0, 8))
        ttk.Label(settings, text="Name").grid(row=0, column=0, sticky="w")
        name_entry = ttk.Entry(settings, textvariable=self.device_name, width=28)
        name_entry.grid(row=0, column=1, sticky="ew", **pad)
        name_entry.bind("<FocusOut>", lambda _e: self.service.set_name(self.device_name.get()))
        ttk.Button(settings, text="Save name", command=lambda: self.service.set_name(self.device_name.get())).grid(row=0, column=2)
        ttk.Label(settings, text="Save received files to").grid(row=1, column=0, sticky="w")
        ttk.Entry(settings, textvariable=self.folder_text).grid(row=1, column=1, sticky="ew", **pad)
        ttk.Button(settings, text="Choose folder", command=self.choose_folder).grid(row=1, column=2)
        ttk.Label(settings, text="Add PC by IP").grid(row=3, column=0, sticky="w")
        manual = ttk.Entry(settings, textvariable=self.manual_address)
        manual.grid(row=3, column=1, sticky="ew", **pad)
        manual.bind("<Return>", lambda _e: self.add_manual_peer())
        ttk.Button(settings, text="Add", command=self.add_manual_peer).grid(row=3, column=2)
        network = ttk.Frame(settings)
        network.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        ttk.Label(network, textvariable=self.network_text).pack(side="left", fill="x", expand=True)
        ttk.Button(network, text="Refresh network", command=self.refresh_network).pack(side="right")
        ttk.Button(network, text="Open Mobile Hotspot", command=self.open_hotspot_settings).pack(side="right", padx=(0, 7))
        settings.columnconfigure(1, weight=1)

        devices = ttk.LabelFrame(self.send_tab, text="Nearby PCs on this Wi-Fi", padding=8)
        devices.pack(fill="both", expand=True, pady=(0, 8))
        self.tree = ttk.Treeview(devices, columns=("name", "address"), show="headings", selectmode="browse", height=6)
        self.tree.heading("name", text="Device")
        self.tree.heading("address", text="Address")
        self.tree.column("name", width=360)
        self.tree.column("address", width=180)
        self.tree.pack(side="left", fill="both", expand=True)
        ttk.Scrollbar(devices, orient="vertical", command=self.tree.yview).pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=lambda first, last: None)

        actions = ttk.Frame(self.send_tab, padding=(0, 0, 0, 10))
        actions.pack(fill="x")
        ttk.Button(actions, text="Refresh devices", command=self.service._announce).pack(side="left")
        ttk.Button(actions, text="Send file…", command=self.pick_and_send).pack(side="right")
        ttk.Label(actions, textvariable=self.progress_text).pack(side="right", padx=15)
        self.progress = ttk.Progressbar(self.send_tab, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(0, 12))

        receiver = ttk.LabelFrame(self.receive_tab, text="Receiver", padding=10)
        receiver.pack(fill="x", pady=(0, 8))
        ttk.Label(receiver, textvariable=self.receiver_text).pack(side="left")
        self.receiver_button = ttk.Button(receiver, text="Pause listening", command=self.toggle_receiver)
        self.receiver_button.pack(side="right")
        receive_settings = ttk.Frame(self.receive_tab, padding=(10, 0, 10, 10))
        receive_settings.pack(fill="x")
        ttk.Label(receive_settings, text="Received files folder:").grid(row=0, column=0, sticky="w")
        ttk.Label(receive_settings, textvariable=self.folder_text).grid(row=0, column=1, sticky="w", padx=8)
        ttk.Button(receive_settings, text="Choose folder", command=self.choose_folder).grid(row=0, column=2)
        ttk.Checkbutton(receive_settings, text="Accept transfers automatically", variable=self.auto_accept).grid(row=1, column=1, sticky="w", padx=8, pady=(6, 0))
        activity = ttk.LabelFrame(self.receive_tab, text="Transfer activity", padding=8)
        activity.pack(fill="both", expand=True)
        self.activity = ttk.Treeview(activity, columns=("time", "state", "details"), show="headings", height=4)
        self.activity.heading("time", text="Time")
        self.activity.heading("state", text="Status")
        self.activity.heading("details", text="Details")
        self.activity.column("time", width=80, stretch=False)
        self.activity.column("state", width=110, stretch=False)
        self.activity.column("details", width=480)
        self.activity.pack(fill="both", expand=True)

    def choose_folder(self) -> None:
        selection = filedialog.askdirectory(initialdir=self.folder)
        if selection:
            self.folder = Path(selection)
            self.folder_text.set(str(self.folder))
            self.service.receive_folder = self.folder

    def add_manual_peer(self) -> None:
        self.service.add_manual_peer(self.manual_address.get())

    def refresh_network(self) -> None:
        self.network_text.set(network_summary())

    def toggle_receiver(self) -> None:
        self.service.set_receiving(not self.service.receiver_enabled.is_set())

    def open_hotspot_settings(self) -> None:
        try:
            os.startfile("ms-settings:network-mobilehotspot")
        except OSError as error:
            messagebox.showerror(APP_NAME, f"Could not open Windows Mobile Hotspot settings: {error}")

    def pick_and_send(self) -> None:
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo(APP_NAME, "Select a nearby PC first.")
            return
        filename = filedialog.askopenfilename(title="Choose a file to send")
        if filename:
            self.service.send_file(selected[0], Path(filename))

    def _set_progress(self, filename: str, current: int, total: int, prefix: str) -> None:
        percent = 100 if total == 0 else current * 100 / total
        self.progress["value"] = percent
        self.progress_text.set(f"{prefix} {filename}: {format_size(current)} / {format_size(total)}")

    def _add_activity(self, state: str, details: str) -> None:
        self.activity.insert("", 0, values=(time.strftime("%H:%M:%S"), state, details))
        entries = self.activity.get_children()
        for entry in entries[50:]:
            self.activity.delete(entry)

    def _process_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "peer":
                    peer, _new = event[1], event[2]
                    self.tree.insert("", "end", iid=peer["id"], values=(peer["name"], peer["host"])) if not self.tree.exists(peer["id"]) else self.tree.item(peer["id"], values=(peer["name"], peer["host"]))
                    self.status.set(f"{len(self.service.peers)} device(s) found")
                elif kind == "peer_removed":
                    if self.tree.exists(event[1]): self.tree.delete(event[1])
                    self.status.set(f"{len(self.service.peers)} device(s) found")
                elif kind == "status": self.status.set(event[1])
                elif kind == "receiver_state":
                    if event[1]:
                        self.receiver_text.set(f"Listening for incoming files on port {TRANSFER_PORT}")
                        self.receiver_button.configure(text="Pause listening")
                    else:
                        self.receiver_text.set("Incoming transfers are paused")
                        self.receiver_button.configure(text="Start listening")
                elif kind == "send_progress": self._set_progress(event[1], event[2], event[3], f"Sending to {event[4]}")
                elif kind == "receive_progress": self._set_progress(event[1], event[2], event[3], "Receiving")
                elif kind == "sent":
                    self.progress["value"] = 100; self.progress_text.set(f"Sent {event[1]} to {event[2]}")
                    self._add_activity("Sent", f"{event[1]} to {event[2]}")
                    messagebox.showinfo(APP_NAME, f"Sent {event[1]} to {event[2]}.")
                elif kind == "received":
                    self.progress["value"] = 100; self.progress_text.set(f"Received {event[1].name}")
                    self._add_activity("Received", f"{event[1].name} saved to {event[1]}")
                    messagebox.showinfo(APP_NAME, f"Saved file to:\n{event[1]}")
                elif kind == "incoming": self._incoming(event[1])
                elif kind == "error":
                    self._add_activity("Failed", event[1])
                    messagebox.showerror(APP_NAME, event[1])
        except queue.Empty:
            pass
        self.root.after(100, self._process_events)

    def _incoming(self, request: dict) -> None:
        self._add_activity("Incoming", f"{request['sender']} wants to send {request['name']} ({format_size(request['size'])})")
        if self.auto_accept.get():
            self.service.respond_to_incoming(request["token"], True)
            return
        answer = messagebox.askyesno(APP_NAME, f"{request['sender']} wants to send:\n\n{request['name']} ({format_size(request['size'])})\n\nAccept?")
        self.service.respond_to_incoming(request["token"], answer)
        if not answer:
            self._add_activity("Declined", f"{request['name']} from {request['sender']}")

    def close(self) -> None:
        self.service.stop()
        self.root.destroy()


if __name__ == "__main__":
    root = Tk()
    ttk.Style().theme_use("vista") if "vista" in ttk.Style().theme_names() else None
    PeerDropApp(root)
    root.mainloop()
