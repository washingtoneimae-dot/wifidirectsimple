import json
import socket
import queue
import tempfile
import time
import unittest
from pathlib import Path

from app import (MAX_FILE_SIZE, NetworkService, TRANSFER_PORT, directed_broadcast, pack_header, parse_ipconfig_interfaces,
                 parse_wifi_status, preferred_address, recv_header, safe_filename, stable_fingerprint, unique_destination, wifi_first_address)


class ProtocolTests(unittest.TestCase):
    def test_round_trip_header(self):
        sender, receiver = socket.socketpair()
        try:
            sender.sendall(pack_header({"magic": "PEERDROP1", "name": "hello.txt", "size": 7}))
            self.assertEqual(recv_header(receiver)["name"], "hello.txt")
        finally:
            sender.close(); receiver.close()

    def test_filename_cannot_escape_folder(self):
        self.assertEqual(safe_filename("../../private.txt"), "private.txt")

    def test_destination_gets_suffix(self):
        folder = Path(self._testMethodName)
        self.assertEqual(unique_destination(folder, "same.txt").name, "same.txt")

    def test_wifi_status_parser(self):
        state, ssid = parse_wifi_status("    State                  : connected\n    SSID                   : Office WiFi\n")
        self.assertEqual((state, ssid), ("Connected", "Office WiFi"))

    def test_prefers_private_lan_ip(self):
        self.assertEqual(preferred_address(["100.64.1.4", "192.168.0.33", "127.0.0.1"]), ("192.168.0.33", 1))

    def test_fingerprint_is_stable_and_not_an_ip(self):
        fingerprint = stable_fingerprint("persistent-installation-id")
        self.assertEqual(fingerprint, stable_fingerprint("persistent-installation-id"))
        self.assertEqual(len(fingerprint), 20)
        self.assertNotIn(".", fingerprint)

    def test_discovery_payload_has_identity_and_capabilities(self):
        service = NetworkService(queue.Queue(), "Test PC", Path("."), device_id="abc123fingerprint")
        packet = json.loads(service._announcement())
        self.assertEqual(packet["fingerprint"], "abc123fingerprint")
        self.assertIn("direct-file", packet["capabilities"])
        self.assertIn("approval", packet["capabilities"])

    def test_manual_address_reads_stable_identity(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            events = queue.Queue()
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                probe.bind(("127.0.0.1", 0))
                port = probe.getsockname()[1]
            service = NetworkService(events, "Lookup PC", root, transfer_port=port, device_id="stable-test-id")
            service.broadcast_enabled = False
            service.start()
            try:
                deadline = time.time() + 3
                while time.time() < deadline:
                    try:
                        if events.get(timeout=.1)[0] == "status":
                            break
                    except queue.Empty:
                        pass
                service.add_manual_peer(f"127.0.0.1:{port}")
                deadline = time.time() + 3
                while time.time() < deadline:
                    try:
                        event = events.get(timeout=.1)
                        if event[0] == "peer":
                            self.assertEqual(event[1]["id"], "stable-test-id")
                            return
                        if event[0] == "error":
                            self.fail(event[1])
                    except queue.Empty:
                        pass
                self.fail("Manual lookup did not return a device identity")
            finally:
                service.stop()

    def test_rejects_oversized_offer(self):
        self.assertGreater(MAX_FILE_SIZE, 0)

    def test_wifi_adapter_beats_virtual_adapter(self):
        interfaces = parse_ipconfig_interfaces("""
Ethernet adapter vEthernet (WSL):
   IPv4 Address. . . . . . . . . . . : 172.22.16.1
   Subnet Mask . . . . . . . . . . . : 255.255.240.0
Wireless LAN adapter Wi-Fi:
   IPv4 Address. . . . . . . . . . . : 192.168.1.44
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
""")
        self.assertEqual(wifi_first_address(interfaces), ("192.168.1.44", 1))
        self.assertEqual(directed_broadcast("192.168.1.44", "255.255.255.0"), "192.168.1.255")

    def test_approved_loopback_transfer(self):
        """Exercise the real TCP offer/approve/send/save path without the GUI."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source.bin"
            payload = b"PeerDrop transfer test\x00" * 12000
            source.write_bytes(payload)
            events = queue.Queue()
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                probe.bind(("127.0.0.1", 0))
                test_port = probe.getsockname()[1]
            service = NetworkService(events, "Test PC", root / "received", transfer_port=test_port)
            service.broadcast_enabled = False
            service.start()
            try:
                deadline = time.time() + 3
                while time.time() < deadline:
                    try:
                        if events.get(timeout=.1)[0] == "status":
                            break
                    except queue.Empty:
                        pass
                else:
                    self.fail("Transfer listener did not start")
                service.peers["self"] = {"id": "self", "name": "Test PC", "host": "127.0.0.1",
                                         "port": test_port, "seen": time.time()}
                service.send_file("self", source)
                deadline = time.time() + 5
                received = sent = False
                while time.time() < deadline and not (received and sent):
                    try:
                        event = events.get(timeout=.1)
                    except queue.Empty:
                        continue
                    if event[0] == "incoming":
                        service.respond_to_incoming(event[1]["token"], True)
                    elif event[0] == "received":
                        received = event[1].read_bytes() == payload
                    elif event[0] == "sent":
                        sent = True
                    elif event[0] == "error":
                        self.fail(event[1])
                self.assertTrue(received, "Receiver did not save the expected bytes")
                self.assertTrue(sent, "Sender did not finish")
            finally:
                service.stop()


if __name__ == "__main__":
    unittest.main()
