"""
test_bidirectional_transfer.py — Simultaneous Full-Duplex Bidirectional Transfer Test

Tests that PC 1 and PC 2 can send and receive files to each other at the exact
same second over the network without stopping, disconnecting, or reversing roles.
"""

import sys
import os
import time
import hashlib
import tempfile
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.transfer import FileReceiver, send_file, TransferProgress

def calculate_sha256(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

def test_bidirectional():
    print("=== Testing Simultaneous Bidirectional Transfer ===")
    
    # Create test directories
    dir_pc1_source = tempfile.mkdtemp()
    dir_pc1_recv = tempfile.mkdtemp()
    dir_pc2_source = tempfile.mkdtemp()
    dir_pc2_recv = tempfile.mkdtemp()
    
    # 20MB test payload PC1 -> PC2
    file_pc1_to_pc2 = os.path.join(dir_pc1_source, "from_pc1.bin")
    with open(file_pc1_to_pc2, "wb") as f:
        f.write(os.urandom(20 * 1024 * 1024))
    hash_pc1 = calculate_sha256(file_pc1_to_pc2)
    
    # 20MB test payload PC2 -> PC1
    file_pc2_to_pc1 = os.path.join(dir_pc2_source, "from_pc2.bin")
    with open(file_pc2_to_pc1, "wb") as f:
        f.write(os.urandom(20 * 1024 * 1024))
    hash_pc2 = calculate_sha256(file_pc2_to_pc1)
    
    # Start Receiver on PC1 (Port 5991) and PC2 (Port 5992)
    pc1_done = threading.Event()
    pc2_done = threading.Event()
    
    receiver_pc1 = FileReceiver(save_dir=dir_pc1_recv, port=5991)
    receiver_pc1.start(done_callback=lambda p: pc1_done.set())
    
    receiver_pc2 = FileReceiver(save_dir=dir_pc2_recv, port=5992)
    receiver_pc2.start(done_callback=lambda p: pc2_done.set())
    
    time.sleep(0.3)
    
    print("1. Launching simultaneous transfers in both directions at the same millisecond...")
    t0 = time.perf_counter()
    
    progress1 = None
    progress2 = None
    
    def send_pc1_to_pc2():
        nonlocal progress1
        progress1 = send_file(host="127.0.0.1", filepath=file_pc1_to_pc2, port=5992)
        
    def send_pc2_to_pc1():
        nonlocal progress2
        progress2 = send_file(host="127.0.0.1", filepath=file_pc2_to_pc1, port=5991)
        
    t1 = threading.Thread(target=send_pc1_to_pc2)
    t2 = threading.Thread(target=send_pc2_to_pc1)
    
    t1.start()
    t2.start()
    
    t1.join()
    t2.join()
    
    pc1_done.wait(timeout=10)
    pc2_done.wait(timeout=10)
    
    elapsed = time.perf_counter() - t0
    
    receiver_pc1.stop()
    receiver_pc2.stop()
    
    print(f"2. Both simultaneous transfers completed in {elapsed:.2f} seconds!")
    print(f"   PC1 -> PC2: {progress1.speed_mbps:.1f} MB/s (Error: {progress1.error})")
    print(f"   PC2 -> PC1: {progress2.speed_mbps:.1f} MB/s (Error: {progress2.error})")
    
    # Check integrity
    rec_pc2_file = os.path.join(dir_pc2_recv, "from_pc1.bin")
    rec_pc1_file = os.path.join(dir_pc1_recv, "from_pc2.bin")
    
    assert os.path.exists(rec_pc2_file), "PC2 did not receive file from PC1"
    assert os.path.exists(rec_pc1_file), "PC1 did not receive file from PC2"
    
    assert calculate_sha256(rec_pc2_file) == hash_pc1, "Hash mismatch on PC2"
    assert calculate_sha256(rec_pc1_file) == hash_pc2, "Hash mismatch on PC1"
    
    print("[PASS] Full-Duplex Bidirectional Transfer PASSED with 100% data integrity!")

if __name__ == "__main__":
    test_bidirectional()
